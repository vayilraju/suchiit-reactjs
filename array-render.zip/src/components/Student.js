import React, { useState } from "react";

function Student(){
    const[id,setId]=useState();
    const[name,setName]=useState();
    const[course,setCourse]=useState();
    const [upStudent,setUpdateStudent]=useState(null);
    const [students,setStudents]=useState([
        {"id":100,"name":"abc","course":"ReactJs"},
        {"id":200,"name":"pqr","course":"Angular"},
        {"id":300,"name":"xyz","course":"VueJs"}
     ]);
     const createStudent = ()=>{
         alert(id+" "+name+" "+course);
         students.push({"id":id,"name":name,"course":course});
         console.log(students.length);
         setStudents(students);
         setId("");
         setName("");
         setCourse("");
         
     }
     const deleteStudent = (sid)=>{
        alert("Deleting Student Id : "+sid);
        const newStudents = students.filter(student => student.id !== sid);
        setStudents(newStudents);
    }
     const updateStudent = (sid)=>{
         alert("Updating Student : "+sid);
         const updateStudentObj = students.find(student=>student.id === sid);
         setId(updateStudentObj.id);
         setName(updateStudentObj.name);
         setCourse(updateStudentObj.course);
         setUpdateStudent(updateStudentObj);
     }
     const handleUpdate = ()=>{
         alert("calling update method here")
         const ustudentData = [...students];//here is ustudentData is temp array
         console.log("temp array",ustudentData);
         const studentIndex = ustudentData.findIndex(student=>student.id===upStudent.id);
         console.log("student object index value ",studentIndex);
         ustudentData.splice(studentIndex,1,{"id":id,"name":name,"course":course});
         console.log("after update tem array ",ustudentData);
         setStudents(ustudentData);
         console.log("check original array ",students);
         setId("");
         setName("");
         setCourse("");
         setUpdateStudent(null);
     }
     return <div className="container">
           <div className="card">
             <div className="card-header">
                <h1>Create Student</h1>
             </div>
             <div className="card-body">
                <div className="mb-3">
                  <label className="form-laber">Student Id</label>
                  <input type="text" 
                     name="id" 
                     className="form-control"
                     onChange={(e)=>{setId(e.target.value)}}
                     />
                </div>
                <div className="mb-3">
                  <label className="form-laber">Student Name</label>
                  <input type="text"
                         name="name" 
                         className="form-control"
                         onChange={(e)=>{setName(e.target.value)}}
                         />
                </div>
                <div className="mb-3">
                  <label className="form-laber">Student Course</label>
                  <input type="text" 
                         name="course"
                         className="form-control"
                         onChange={(e)=>{setCourse(e.target.value)}}
                         />
                </div>
                <button className="btn btn-primary" onClick={createStudent}>Create</button><br/>
                {id} {name} {course}
             </div>
           </div>
           <div className="card">
             <div className="card-header">
                 <h1>Student List</h1>
             </div>
             <div className="card-body">
                <table className="table table-striped">
                   <thead>
                       <tr>
                           <th>Id</th>
                           <th>Name</th>
                           <th>Course</th>
                           <th>Action</th>
                       </tr>
                   </thead>
                   <tbody>
                       {
                           students.map((student,index)=>{
                               return <tr key={index}>
                                   <td>{student.id}</td>
                                   <td>{student.name}</td>
                                   <td>{student.course}</td>
                                   <td>
                                       <button className="btn btn-primary" onClick={()=>updateStudent(student.id)}>Update</button>
                                       <button className="btn btn-danger" onClick={()=>deleteStudent(student.id)}>Delete</button>
                                   </td>
                               </tr>
                           })
                       }
                   </tbody>
                </table>
             </div>
           </div>
           <div className="card">
             <div className="card-header">
                 <h1>Update Student</h1>
             </div>
             <div className="card-body">
               <div className="mb-3">
                  <label className="form-label">Student Id</label>
                  <input
                    type="text"
                    value={id}
                    className="form-control"
                    disabled
                  />
               </div>
               <div className="mb-3">
                  <label className="form-label">Student Name</label>
                  <input
                    type="text"
                    value={name}
                    className="form-control"
                    onChange={(e)=>{setName(e.target.value)}}
                  />
               </div>
               <div className="mb-3">
                  <label className="form-label">Student Course</label>
                  <input
                    type="text"
                    value={course}
                    className="form-control"
                    onChange={(e)=>{setCourse(e.target.value)}}
                  />
               </div>
               <button className="btn btn-primary" onClick={handleUpdate}>Update</button><br/>
               {id} {name} {course}
             </div>
           </div>
     </div>
      
     
}
export default Student;