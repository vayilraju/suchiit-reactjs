import './App.css';
import Student from './components/Student';

function App() {
  return (
    <div className="App">
      <Student/>
    </div>
  );
}

export default App;
